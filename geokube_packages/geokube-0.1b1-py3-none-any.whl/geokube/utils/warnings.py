class DomainWarning(Warning):
    """Warning involved with the Domain"""


class GenericAxisTypeWarning(Warning):
    """Using generic axis type"""
