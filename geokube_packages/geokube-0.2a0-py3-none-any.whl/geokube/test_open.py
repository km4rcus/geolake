from geokube import open_datacube

kube = open_datacube("tMin1zoneDAILY.nc")
