class EmptyDataCubeError(ValueError):
    """Empty DataCube"""

class CacheNotExist(RuntimeError):
    """Cache does not exist"""