class EmptyDataCubeError(ValueError):
    """Empty DataCube"""
