class CacheNotExist(RuntimeError):
    """Raise when cache for product is not created"""
