class DomainWarning(Warning):
    """Warning involved with the Domain"""


class GenericAxisWarning(Warning):
    """Using generic axis type"""
